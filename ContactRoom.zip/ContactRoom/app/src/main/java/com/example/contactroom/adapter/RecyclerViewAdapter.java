package com.example.contactroom.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.RecyclerView;

import com.example.contactroom.MainActivity;
import com.example.contactroom.R;
import com.example.contactroom.model.Contact;

import java.util.List;
import java.util.Objects;

public class RecyclerViewAdapter  extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    private onContactClickListener ocMain;
    private List<Contact> contactList;
    private Context context;

    public RecyclerViewAdapter(List<Contact> contactList, Context context, onContactClickListener oc) {
        this.contactList = contactList;
        this.context = context;
        this.ocMain = oc;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_row, parent, false);
        return new ViewHolder(view, ocMain);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Contact contact = Objects.requireNonNull(contactList.get(position));
        holder.name.setText(contact.getName());
        holder.occupation.setText(contact.getOccupation());
    }

    @Override
    public int getItemCount() {
        return Objects.requireNonNull(contactList.size());
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        onContactClickListener oc;
        public TextView name;
        public TextView occupation;
        public ViewHolder(@NonNull View itemView, onContactClickListener oc1) {
            super(itemView);
            name = itemView.findViewById(R.id.rowNameTextView);
            occupation = itemView.findViewById(R.id.rowOccupationTextView);
            this.oc = oc1;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            oc.onContactClick(getAdapterPosition());
        }
    }

    public interface onContactClickListener{
        void onContactClick(int position);
    }
}
