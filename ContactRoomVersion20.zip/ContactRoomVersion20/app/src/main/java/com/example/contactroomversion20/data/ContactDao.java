package com.example.contactroomversion20.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.contactroomversion20.model.Contact;

import java.util.List;

@Dao
public interface ContactDao {

    // Inserting new data in the database
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Contact contact);

    // Reading data from the database
    @Query("SELECT * FROM contactTable ORDER BY experience DESC")
    LiveData<List<Contact>> getAllContacts();

    @Query("SELECT * FROM contactTable WHERE id == :id")
    LiveData<Contact> get(int id);

    // Updating data in the database
    @Update
    void update(Contact contact);

    // deleting from the database
    @Query("DELETE FROM contactTable")
    void deleteAll();

    @Delete
    void delete(Contact contact);
}
