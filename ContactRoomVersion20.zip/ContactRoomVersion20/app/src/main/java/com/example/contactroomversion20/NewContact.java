package com.example.contactroomversion20;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.contactroomversion20.model.Contact;
import com.example.contactroomversion20.model.ContactViewModel;

public class NewContact extends AppCompatActivity {

    public static final String NAME_REPLY = "name_reply";
    public static final String NAME_OCCUPATION = "occupation_reply";
    public static final String NAME_EXPERIENCE = "experience_reply";
    private EditText enterName;
    private EditText enterOccupation;
    private EditText enterExperience;
    private Button saveButton;
    private Button updateButton;
    private Button delButton;
    private int contactId = 0;
    private boolean isEdit = false;
    private ContactViewModel contactViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_contact);
        enterName = findViewById(R.id.enterName);
        enterOccupation = findViewById(R.id.enterOccupation);
        enterExperience = findViewById(R.id.enterExperience);
        saveButton = findViewById(R.id.saveButton);
        updateButton = findViewById(R.id.updateButton);
        delButton = findViewById(R.id.delButton);
        contactViewModel = new ViewModelProvider.AndroidViewModelFactory(NewContact.this.getApplication()).create(ContactViewModel.class);

        if (getIntent().hasExtra(MainActivity.CONTACT_ID)) {
            contactId = getIntent().getIntExtra(MainActivity.CONTACT_ID, 0);
            contactViewModel.get(contactId).observe(this, contact -> {
                if (contact != null) {
                    enterName.setText(contact.getName());
                    enterOccupation.setText(contact.getOccupation());
                    enterExperience.setText(String.valueOf(contact.getExperience()));
                }
            });
            isEdit = true;
        }

        // save button
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent replyIntent = new Intent();
                if(!TextUtils.isEmpty(enterName.getText()) && !TextUtils.isEmpty(enterOccupation.getText())) {
                    String name = enterName.getText().toString().trim();
                    String occupation = enterOccupation.getText().toString().trim();
                    int experience = Integer.parseInt(enterExperience.getText().toString().trim());
                    replyIntent.putExtra(NAME_REPLY, name);
                    replyIntent.putExtra(NAME_OCCUPATION, occupation);
                    replyIntent.putExtra(NAME_EXPERIENCE, experience);
                    setResult(RESULT_OK, replyIntent);
                }else{
                    setResult(RESULT_CANCELED, replyIntent);
                }
                finish();
            }
        });

        // update button
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = contactId;
                String name = enterName.getText().toString().trim();
                String occupation = enterOccupation.getText().toString().trim();
                int experience = Integer.parseInt(enterExperience.getText().toString().trim());
                if(!TextUtils.isEmpty(name) && !TextUtils.isEmpty(occupation)) {
                    Contact contact = new Contact();
                    contact.setId(id);
                    contact.setName(name);
                    contact.setOccupation(occupation);
                    contact.setExperience(experience);
                    ContactViewModel.update(contact);
                    finish();
                }
            }
        });

        // delete button
        delButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Contact contact = new Contact();
                contact.setId(contactId);
                contact.setName(enterName.getText().toString().trim());
                contact.setOccupation(enterOccupation.getText().toString().trim());
                contact.setExperience(Integer.parseInt(enterExperience.getText().toString().trim()));
                ContactViewModel.delete(contact);
                finish();
            }
        });

        if(isEdit) {
            saveButton.setVisibility(View.GONE);
        }else {
            delButton.setVisibility(View.GONE);
            updateButton.setVisibility(View.GONE);
        }


    }
}