package com.example.contactroomversion20.model;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.contactroomversion20.data.ContactRepository;

import java.util.List;

public class ContactViewModel extends AndroidViewModel {

    public static ContactRepository contactRepository;
    public final LiveData<List<Contact>> allContacts;

    public ContactViewModel(@NonNull Application application) {
        super(application);
        contactRepository = new ContactRepository(application);
        allContacts = contactRepository.getAllData();
    }
    public LiveData<List<Contact>> getAllContacts() { return allContacts;}
    public static void insert(Contact contact) {contactRepository.insert(contact);}
    public LiveData<Contact> get(int id) {return contactRepository.get(id);}
    public static void update(Contact contact) {contactRepository.update(contact);}
    public static void delete(Contact contact) {contactRepository.delete(contact);}
}
